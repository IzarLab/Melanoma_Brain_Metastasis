Author: Somnath Tagore

This is a usage guide for the ARACNe script in this directory.

Arguments:
	-n	Run ID (name for this job)
	-b 	Base Directory (directory where results will be stored)
	-i	Input expression file (.rds format; genes X samples)
	-r	Regulator set (.tsv or .csv, with regulators in lines)
	-k	Flag for cleanup; only use if you want the script to NOT delete bootstraps

Usage example:

bash aracne-script.sh -n MY-ARACNE-RUN -b ./Path-to-directory/new-network/ -i ./Path-to-directory/my_metaCell_matrix.rds -r ./Path-to-directory/ARACNe/human_ensg/tf-ensembl.txt -r ./Path-to-directory/ARACNe/human_ensg/cotf-ensembl.txt

You can include up to four regulator sets with the -r flag. Using any more than four at once will launch too many job and overwhelm the cluster's 1000 jobs / user limit.

You can find directories with regulator lists in the same folder as this script.
